package nineA;

import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import java.awt.event.*;


public class login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame();
		
		
		// Creation of frame
		frame.setTitle("CyberWolf");
		frame.setLocation(700, 300);
		frame.setSize(400, 600);

		// Color Theme and layout
		Container con = frame.getContentPane();
		Color cwBG = new Color(36,43,51);
		Color cwMain = new Color(95,232,184);
		con.setBackground(cwBG);
		con.setLayout(null);
		 
		
		
		//Username Box
		JTextField username = new JTextField();
		username.setBounds(90,108,205,30);
		username.setForeground(Color.white);
		username.setFont(new Font("Arial",Font.BOLD,16));
		username.setBackground(cwBG);
		username.setBorder(BorderFactory.createLineBorder(cwMain, 3));
		username.setOpaque(true);
		
		
		//Labels username box
		JLabel uindicator = new JLabel();
		uindicator.setBounds(username.getX(), username.getY()-30, username.getWidth(),username.getHeight());;
		uindicator.setBackground(cwBG);
		uindicator.setForeground(Color.white);
		uindicator.setOpaque(true);
		uindicator.setText("USERNAME");
		
		
		
		//Password Box
		JPasswordField password = new JPasswordField();
		password.setBounds(username.getX(), username.getY()+75, username.getWidth(), username.getHeight());
		password.setForeground(Color.white);
		password.setFont(new Font("Verdana",Font.PLAIN,16));
		password.setBackground(cwBG);
		password.setBorder(BorderFactory.createLineBorder(cwMain, 3));
		password.setOpaque(true);
		
		
		//Labels password box
		JLabel pindicator = new JLabel();
		pindicator.setBounds(password.getX(), password.getY()-30, password.getWidth(),password.getHeight());;
		pindicator.setBackground(cwBG);
		pindicator.setForeground(Color.white);
		pindicator.setOpaque(true);
		pindicator.setText("PASSWORD");
		
		
		//Login Button
		JButton submit = new JButton();
		submit.setBounds(90,250,100,30);
		submit.setBackground(cwMain);
		submit.setForeground(new Color(46,110,105));
		submit.setFont(new Font("Arial",Font.BOLD,13));
		submit.setText("LOGIN");
	
			
		
		
		//Sign up button
		JButton register = new JButton();
		register.setBounds(194,250,100,30);
		register.setBackground(cwMain);
		register.setForeground(new Color(46,110,105));
		register.setFont(new Font("Arial",Font.BOLD,13));
		register.setText("SIGN-UP");
		
		
		
		//decorations
		ImageIcon img = new ImageIcon("CyberWolf.jpg");
		JLabel deco = new JLabel(img);
		deco.setBounds(82,290,img.getIconWidth(),img.getIconHeight());
		ImageIcon icon = new ImageIcon("CyberWolf.png");                       
		frame.setIconImage(icon.getImage());
		
		
		
		
		//Success or Not
		JLabel check = new JLabel();
		check.setBounds(username.getX(), username.getY()-80, username.getWidth(), username.getHeight());
		check.setForeground(cwMain);
		check.setOpaque(true);
		check.setFont(new Font("Arial",Font.BOLD,13));
		check.setBackground(cwBG);		
		
		
		// Add
		con.add(username);
		con.add(uindicator);
		con.add(password);
		con.add(pindicator);
		con.add(submit);
		con.add(register);
		con.add(deco);
		con.add(check);
		
		
		
		//Confirmed successful login
		ArrayList<String> userPass = new ArrayList<>();
		userPass.add("daovi");
		userPass.add("pass123");
		
		
		// I didn't want to make a class outside of main
				submit.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						//Converts the char characters into a string
						char[] charpassin = password.getPassword();
						String passwordInput = new String(charpassin);
						
						
						//if statement that checks strings, for some reason == operand doesn't work
						if (username.getText().equals(userPass.get(0)) && passwordInput.equals(userPass.get(1))) {
							check.setBounds(username.getX()+40, username.getY()-80, username.getWidth(), username.getHeight());
							check.setText("Login Successful!");
						}
						else {
							check.setText("Incorrect username/password");
						}
						
					}
				});
		
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
