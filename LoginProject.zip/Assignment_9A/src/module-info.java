module Assignment_9A {
	requires java.desktop;
}