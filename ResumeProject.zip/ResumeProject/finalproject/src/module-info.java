module finalproject {
	requires java.desktop;
}