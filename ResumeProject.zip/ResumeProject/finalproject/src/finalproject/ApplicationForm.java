package finalproject;

import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.awt.event.*;
import java.io.IOException;
import java.io.PrintWriter;

public class ApplicationForm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Window Object
		JFrame frame = new JFrame();
		
		
		// colors
		Color cwBG = new Color(36,43,51);
		Color cwMain = new Color(95,232,184);
		Container con = frame.getContentPane();
		con.setBackground(cwBG);
		con.setLayout(null);
		
		
		//Frame/WIndow Setup
		frame.setTitle("Application");
		frame.setLocation(380, 50);
		frame.setSize(1200, 800);
		
		
		//Application Title
		JLabel title = new JLabel();
		title.setBounds(85,10,400,80);;
		title.setForeground(cwMain);
		title.setFont(new Font("Consolas",Font.BOLD,30));
		title.setText("CyberWolf Application");
		
		
		
		//name boxes///////////////////////////////////////////////
		JTextField fname = new JTextField();
		fname.setBounds(90,140,205,30);
		fname.setForeground(Color.white);
		fname.setFont(new Font("Consolas",Font.BOLD,16));
		fname.setBackground(cwBG);
		fname.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		
	
		JLabel fnamelabel = new JLabel();
		fnamelabel.setBounds(fname.getX(), fname.getY()-30, fname.getWidth(),fname.getHeight());;
		fnamelabel.setBackground(cwBG);
		fnamelabel.setForeground(cwMain);
		fnamelabel.setFont(new Font("Consolas",Font.BOLD,16));
		fnamelabel.setText("First Name: ");
		
		
		JTextField lname = new JTextField();
		lname.setBounds(fname.getX()+300, fname.getY(), fname.getWidth(),fname.getHeight());
		lname.setForeground(Color.white);
		lname.setFont(new Font("Consolas",Font.BOLD,16));
		lname.setBackground(cwBG);
		lname.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		
		JLabel lnamelabel = new JLabel();
		lnamelabel.setBounds(lname.getX(), lname.getY()-30, lname.getWidth(),lname.getHeight());;
		lnamelabel.setBackground(cwBG);
		lnamelabel.setForeground(cwMain);
		lnamelabel.setText("Last Name: ");
		lnamelabel.setFont(new Font("Consolas",Font.BOLD,16));
		////////////////////////////////////////////////////////////
		
		//Gender
		JRadioButton male = new JRadioButton("Male");
		JRadioButton female = new JRadioButton("Female");
		JRadioButton na = new JRadioButton("N/A");
		
		
		
		
		male.setBounds(90,235,100,30);
		male.setOpaque(false);
		male.setForeground(cwMain);
		male.setFont(new Font("Consolas",Font.BOLD,16));
		
		female.setBounds(150,235,100,30);
		female.setOpaque(false);
		female.setForeground(cwMain);
		female.setFont(new Font("Consolas",Font.BOLD,16));
		
		na.setBounds(230,235,100,30);
		na.setOpaque(false);
		na.setForeground(cwMain);
		na.setFont(new Font("Consolas",Font.BOLD,16));
		
		JLabel genderLabel = new JLabel();
		genderLabel.setBounds(male.getX(), male.getY()-30, lname.getWidth(),lname.getHeight());;
		genderLabel.setBackground(cwBG);
		genderLabel.setForeground(cwMain);
		genderLabel.setText("Gender: ");
		genderLabel.setFont(new Font("Consolas",Font.BOLD,16));
		//Date of Birth//////////////////////////////////////
		JLabel dobLabel = new JLabel("Date of Birth:");
		dobLabel.setFont(new Font("Consolas",Font.BOLD,16));
		dobLabel.setBounds(90, 280, 150, 30);
		dobLabel.setForeground(cwMain);

		// Day
		String[] days = new String[31]; // Assuming max 31 days
		for (int i = 0; i < 31; i++) {
		    days[i] = String.valueOf(i + 1);
		}
		JComboBox<String> dayBox = new JComboBox<>(days);
		dayBox.setBounds(90, 310, 60, 30);
		dayBox.setBackground(cwBG);
		dayBox.setForeground(cwMain);

		// Month
		String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		JComboBox<String> monthBox = new JComboBox<>(months);
		monthBox.setBounds(160, 310, 100, 30);
		monthBox.setBackground(cwBG);
		monthBox.setForeground(cwMain);

		// Year
		String[] years = new String[100]; // Assuming 100 years range
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		for (int i = 0; i < 100; i++) {
		    years[i] = String.valueOf(currentYear - i);
		}
		
		JComboBox<String> yearBox = new JComboBox<>(years);
		yearBox.setBounds(270, 310, 80, 30);
		yearBox.setBackground(cwBG);
		yearBox.setForeground(cwMain);
		////////////////////////////////////////////////////////
		
		
		// phone and address ///////////////////////////////
		JTextField phone = new JTextField();
		phone.setBounds(male.getX()+300, male.getY(), fname.getWidth(),fname.getHeight());
		phone.setForeground(Color.white);
		phone.setFont(new Font("Arial",Font.BOLD,16));
		phone.setBackground(cwBG);
		phone.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		phone.setFont(new Font("Consolas",Font.BOLD,16));
		
		
		JLabel phoneLabel = new JLabel();
		phoneLabel.setBounds(phone.getX(), phone.getY()-30, phone.getWidth(),phone.getHeight());;
		phoneLabel.setBackground(cwBG);
		phoneLabel.setForeground(cwMain);
		phoneLabel.setFont(new Font("Consolas",Font.BOLD,16));
		phoneLabel.setText("Phone: ");
		
		JTextField address = new JTextField();
		address.setBounds(90, 400, 205,30);
		address.setForeground(Color.white);
		address.setFont(new Font("Arial",Font.BOLD,16));
		address.setBackground(cwBG);
		address.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		address.setFont(new Font("Consolas",Font.BOLD,16));
		
		JLabel addressLabel = new JLabel();
		addressLabel.setBounds(address.getX(), address.getY()-30, address.getWidth(),address.getHeight());;
		addressLabel.setBackground(cwBG);
		addressLabel.setForeground(cwMain);
		addressLabel.setFont(new Font("Consolas",Font.BOLD,16));
		addressLabel.setText("Address: ");
		
		JTextField email = new JTextField();
		email.setBounds(address.getX()+300, 400, 205,30);
		email.setForeground(Color.white);
		email.setFont(new Font("Arial",Font.BOLD,16));
		email.setBackground(cwBG);
		email.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		email.setFont(new Font("Consolas",Font.BOLD,16));
		
		JLabel 		emailLabel = new JLabel();
		emailLabel.setBounds(email.getX(), email.getY()-30, email.getWidth(),email.getHeight());;
		emailLabel.setBackground(cwBG);
		emailLabel.setForeground(cwMain);
		emailLabel.setFont(new Font("Consolas",Font.BOLD,16));
		emailLabel.setText("E-mail: ");
		
		JTextField city = new JTextField();
		city.setBounds(90, 500, 205,30);
		city.setForeground(Color.white);
		city.setFont(new Font("Arial",Font.BOLD,16));
		city.setBackground(cwBG);
		city.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		city.setFont(new Font("Consolas",Font.BOLD,16));
		
		JLabel cityLabel = new JLabel();
		cityLabel.setBounds(city.getX(), city.getY()-30, city.getWidth(),city.getHeight());;
		cityLabel.setBackground(cwBG);
		cityLabel.setForeground(cwMain);
		cityLabel.setFont(new Font("Consolas",Font.BOLD,16));
		cityLabel.setText("City: ");
		
		JTextField zip = new JTextField();
		zip.setBounds(390, 500, 205,30);
		zip.setForeground(Color.white);
		zip.setFont(new Font("Arial",Font.BOLD,16));
		zip.setBackground(cwBG);
		zip.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		zip.setFont(new Font("Consolas",Font.BOLD,16));
		
		JLabel zipLabel = new JLabel();
		zipLabel.setBounds(zip.getX(), zip.getY()-30, zip.getWidth(),zip.getHeight());;
		zipLabel.setBackground(cwBG);
		zipLabel.setForeground(cwMain);
		zipLabel.setFont(new Font("Consolas",Font.BOLD,16));
		zipLabel.setText("ZIP Code: ");
		////////////////////////////////////////////////
		
		//Ethnicity
		String[] ethnicities = {"Asian", "Black or African American", "Hispanic or Latino", "White", "Other"};
		JComboBox<String> ethnicity = new JComboBox<>(ethnicities);
		ethnicity.setBounds(90, 600, 180, 30);
		ethnicity.setBackground(cwBG);
		ethnicity.setForeground(cwMain);

		JLabel ethnicityLabel = new JLabel("Ethnicity:");
		ethnicityLabel.setFont(new Font("Consolas", Font.BOLD, 16));
		ethnicityLabel.setBounds(90, ethnicity.getY()-30, 100, 30);
		ethnicityLabel.setForeground(cwMain);

		
		//Ethnicity
		String[] veteranStatuses = {"Yes", "No", "I would rather not disclose"};
		JComboBox<String> veteran = new JComboBox<>(veteranStatuses);
		veteran.setBounds(ethnicity.getX()+300, 600, 180, 30);
		veteran.setBackground(cwBG);
		veteran.setForeground(cwMain);

		JLabel veteranLabel = new JLabel("Veteran:");
		veteranLabel.setFont(new Font("Consolas", Font.BOLD, 16));
		veteranLabel.setBounds(veteran.getX(), veteran.getY()-30, 100, 30);
		veteranLabel.setForeground(cwMain);

		//Cover Letter
		JTextArea coverLetter = new JTextArea();
		coverLetter.setBounds(lname.getX()+300, lname.getY(), 400, 200);
		coverLetter.setForeground(Color.white);
		coverLetter.setFont(new Font("Consolas", Font.BOLD, 14));
		coverLetter.setBackground(cwBG);
		coverLetter.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		coverLetter.setLineWrap(true);
		coverLetter.setWrapStyleWord(true);
		
		JLabel coverLetterLabel = new JLabel("Cover Letter:");
		coverLetterLabel.setFont(new Font("Consolas", Font.BOLD, 16));
		coverLetterLabel.setBounds(coverLetter.getX(), coverLetter.getY()-30, 150, 30);
		coverLetterLabel.setForeground(cwMain);
		
		//experience
		JTextArea experience = new JTextArea();
		experience.setBounds(coverLetter.getX(), coverLetter.getY() + coverLetter.getHeight()+50, 400, 150);
		experience.setForeground(Color.white);
		experience.setFont(new Font("Consolas", Font.BOLD, 14));
		experience.setBackground(cwBG);
		experience.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		experience.setLineWrap(true);
		experience.setWrapStyleWord(true);

		JLabel experienceLabel = new JLabel("Experience:");
		experienceLabel.setFont(new Font("Consolas", Font.BOLD, 16));
		experienceLabel.setBounds(experience.getX(), experience.getY() - 30, 150, 30);
		experienceLabel.setForeground(cwMain);

		// Education
		JTextArea education = new JTextArea();
		education.setBounds(experience.getX(), experience.getY() + experience.getHeight() + 50, 400, 150);
		education.setForeground(Color.white);
		education.setFont(new Font("Consolas", Font.BOLD, 14));
		education.setBackground(cwBG);
		education.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		education.setLineWrap(true);
		education.setWrapStyleWord(true);

		JLabel educationLabel = new JLabel("Education:");
		educationLabel.setFont(new Font("Consolas", Font.BOLD, 16));
		educationLabel.setBounds(education.getX(), education.getY() - 30, 150, 30);
		educationLabel.setForeground(cwMain);
		
		JButton submit = new JButton("Submit");
		submit.setBounds(400, 690, 150, 50);
		submit.setFont(new Font("Consolas", Font.BOLD, 16));
		submit.setForeground(cwMain);
		submit.setBackground(cwBG);
		submit.setBorder(BorderFactory.createLineBorder(cwMain, 2));
		submit.setFocusPainted(false);
		
		submit.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            PrintWriter writer = new PrintWriter("application.txt");

		            // Write personal information
		            writer.println("First Name: " + fname.getText());
		            writer.println("Last Name: " + lname.getText());
		            writer.println("Gender: " + (male.isSelected() ? "Male" : (female.isSelected() ? "Female" : "N/A")));
		            writer.println("Date of Birth: " + dayBox.getSelectedItem() + " " + monthBox.getSelectedItem() + " " + yearBox.getSelectedItem());
		            writer.println("Phone: " + phone.getText());
		            writer.println("Email: " + email.getText());
		            writer.println("Ethnicity: " + ethnicity.getSelectedItem());
		            writer.println();
		            writer.println("Address: " + address.getText());
		            writer.println("City: " + city.getText());
		            writer.println("ZIP Code: " + zip.getText());
		            writer.println();
		            writer.println("Veteran: " + veteran.getSelectedItem());
		            writer.println();

		            // Write cover letter, experience, and education
		            writer.println("Cover Letter:");
		            writer.println(coverLetter.getText());
		            writer.println();
		            writer.println("Experience:");
		            writer.println(experience.getText());
		            writer.println();
		            writer.println("Education:");
		            writer.println(education.getText());
		            writer.close();
		            JOptionPane.showMessageDialog(frame, "Application submitted successfully!");
		            
		        } catch (IOException ex) {
		            JOptionPane.showMessageDialog(frame, "Error occurred while saving the application.");		         
		        }
		    }
		});
		//adds elements to container//////////
			//names, application title, and certain labels
		con.add(fname);
		con.add(fnamelabel);
		
		con.add(lname);
		con.add(lnamelabel);
		
		con.add(title);
		con.add(genderLabel);
		con.add(ethnicityLabel);
		
		con.add(phone);
		con.add(phoneLabel);
		
			//Buttons
		con.add(na);
		con.add(male);
		con.add(female);
		
			//Combo Boxes
		con.add(dobLabel);
		con.add(dayBox);
		con.add(monthBox);
		con.add(yearBox);
		con.add(ethnicity);
		
			//Address information
		con.add(address);
		con.add(addressLabel);
		
		con.add(city);
		con.add(cityLabel);
		
		con.add(zip);
		con.add(zipLabel);
		
			//cover letter
		con.add(coverLetter);
		con.add(coverLetterLabel);
		
			//email
		con.add(email);
		con.add(emailLabel);
		
			//veteran status
		con.add(veteran);
		con.add(veteranLabel);
		
			//experience and education
		con.add(education);
		con.add(educationLabel);
		con.add(experience);
		con.add(experienceLabel);
		
			//submit
		con.add(submit);
		/////////////////////////////////////
		
		
		
		//Executes the window and makes it visible
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
