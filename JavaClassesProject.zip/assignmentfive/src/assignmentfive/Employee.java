package assignmentfive;
import java.util.Date;

public class Employee extends Person {

	private Date dateHired;
	private String office;
	private long salary;



//constructor
 Employee(String firstName, String lastName, String address, String number, String email, String office, long salary, Date dateHired) {
		super(firstName, lastName, address, number, email);
		this.setOffice(office);
		this.setSalary(salary);
		this.setDateHired(dateHired);

 }


//getter and setter methods
public Date getDateHired() {return dateHired;}
public void setDateHired(Date dateHired) {this.dateHired = dateHired;}



public String getOffice() {return office;}
public void setOffice(String office) {this.office = office;}



public String getSalary() {return "$" + salary;}
public void setSalary(long salary) {this.salary = salary;}
}


