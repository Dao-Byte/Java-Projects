package assignmentfive;

public class Staff extends Person{

	
//data fields
	
	private String title;
	
// Constructor
	Staff(String firstName, String lastName, String address, String number, String email, String title) {
		super(firstName, lastName, address, number, email);
		this.setTitle(title);
		
	}

	public String getTitle() {return title;}
	public void setTitle(String title) {this.title = title;}

}
