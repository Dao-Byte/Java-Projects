package assignmentfive;

public class Student extends Person {

	
//data fields
	private static String status;
	
//constructor

	Student(String firstName, String lastName, String address, String number, String email, String status) {
		super(firstName, lastName, address, number, email);
		Student.status = status;
	}

// getter
	public String getStatus() {
		return Student.status;
	}
// setter
	public void setStatus(String status) {
		Student.status = status;
	}


}
