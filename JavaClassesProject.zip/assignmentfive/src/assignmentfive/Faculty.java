package assignmentfive;

public class Faculty extends Person {

// data fields
	private String officehours;
	private String rank;
	
// constructor
	
	Faculty(String firstName, String lastName, String address, String number, String email, String rank, String officehours) {
		super(firstName, lastName, address, number, email);
		this.officehours = officehours;
		this.rank = rank;
		
	}

	public String getRank() {return rank;}
	public void setRank(String rank) {this.rank = rank;}
	
	public String getOfficeHours() {return this.officehours;}
	public void setOfficeHours(String officehours) {this.officehours = officehours;}
	

}
