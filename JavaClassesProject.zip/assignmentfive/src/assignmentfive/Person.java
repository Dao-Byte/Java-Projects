package assignmentfive;

public class Person {

//data fields
	private String lname;
	private String fname;
	private String address;
	private String phoneNumber;
	private String email;
	
//constructor
	Person(String firstName, String lastName, String address, String number, String email){
		this.fname = firstName;
		this.lname = lastName;
		this.address = address;
		this.phoneNumber = number;
		this.email = email;
	}
	
//setter
	public void setName(String firstName, String lastName){
		fname = firstName;
		lname = lastName;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
//getter
	public String getFirstName() {return fname;}
	public String getLastName() {return lname;}
	public String getAddress() {return address;}
	public String getEmail() {return email;}
	public String getPhoneNumber() {return phoneNumber;}

// toString() override
	public String toString(){
		return "Class: " + getClass().getSimpleName() + 

				" || First Name: " + this.fname +
				" || Last Name: " + this.lname;
		}
}
