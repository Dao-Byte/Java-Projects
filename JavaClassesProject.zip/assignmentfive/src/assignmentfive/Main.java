package assignmentfive;

import java.util.Date;
public class Main {

	public static void main(String[] args) {
	
		Person vi = new Person("Vi", "Dao", "6020 Meadow Spring CT", "(513) 394-2862", "daovi@mail.uc.edu");
		Student john = new Student("John", "Doe", "123 Street", "(513) 123-4567","johndoe@gmail.com","Sophomore");
		Employee melina = new Employee("Melina", "Trace", "123 Street", "(513) 123-4567","123@gmail.com", "Room 315F", 60666, new Date(2015, 12, 05, 11, 40));
		Faculty johnson = new Faculty("Johnson", "Doe", "123 Street", "(513) 123-4567","123@gmail.com", "Professor", "2 PM - 6 PM");
		Staff king = new Staff("King", "Weissman","123 Street", "(513) 123-4567","123@gmail.com", "Director of Education");
		
		System.out.println(vi.toString());
		System.out.println(john.toString());
		System.out.println(melina.toString());
		System.out.println(johnson.toString());
		System.out.println(king.toString());
		
		System.out.println(" ");
		System.out.println("--------------------------------------------");
		System.out.println(" ");
		
		System.out.println(vi.toString());
		System.out.println(vi.getPhoneNumber());
		System.out.println(vi.getAddress());
		System.out.println(vi.getEmail());
		
		System.out.println(" ");
		System.out.println("--------------------------------------------");
		System.out.println(" ");
		
		
		System.out.println(melina.getDateHired());
		System.out.println(melina.getOffice());
		System.out.println(melina.getSalary());
		System.out.println(john.getStatus());
		System.out.println(johnson.getRank());
		System.out.println(johnson.getOfficeHours());
		System.out.println(king.getTitle());
		
	}

}
